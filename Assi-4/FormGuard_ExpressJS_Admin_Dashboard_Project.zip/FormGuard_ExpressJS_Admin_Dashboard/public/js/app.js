document.addEventListener("DOMContentLoaded", () => {
  const search = document.getElementById("tableSearch");
  const table = document.getElementById("usersTable");
  const count = document.getElementById("visibleCount");
  if (search && table) {
    search.addEventListener("input", () => {
      const term = search.value.toLowerCase().trim();
      let visible = 0;
      table.querySelectorAll("tbody tr").forEach(row => {
        const match = row.innerText.toLowerCase().includes(term);
        row.hidden = !match;
        if (match) visible++;
      });
      if (count) count.textContent = visible;
    });
  }
});
const express = require("express");
const session = require("express-session");
const path = require("path");
const fs = require("fs");
const { body, validationResult } = require("express-validator");

const app = express();
const PORT = process.env.PORT || 3000;
const DATA_FILE = path.join(__dirname, "data", "users.json");

app.use(express.urlencoded({ extended: false }));
app.use(express.json());
app.use(session({
  secret: process.env.SESSION_SECRET || "replace-this-demo-secret-before-deployment",
  resave: false,
  saveUninitialized: false,
  cookie: { httpOnly: true, sameSite: "lax", secure: process.env.NODE_ENV === "production" }
}));
app.use(express.static(path.join(__dirname, "public")));

function readUsers() {
  try { return JSON.parse(fs.readFileSync(DATA_FILE, "utf8")); }
  catch { return []; }
}
function saveUsers(users) {
  fs.writeFileSync(DATA_FILE, JSON.stringify(users, null, 2));
}
function escapeHtml(value = "") {
  return String(value).replace(/[&<>"']/g, ch => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
  }[ch]));
}
function requireAdmin(req, res, next) {
  if (req.session && req.session.isAdmin) return next();
  return res.redirect("/admin/login");
}
function page(title, content, active = "") {
  return `<!doctype html><html lang="en"><head><meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>${escapeHtml(title)} | FormGuard</title>
  <link rel="stylesheet" href="/css/styles.css"></head><body>
  <header class="topbar"><a class="brand" href="/"><span class="brand-mark">F</span> FormGuard</a>
  <nav><a href="/">Registration</a><a href="/admin/login">Admin</a></nav></header>
  <main>${content}</main><footer>FormGuard · Express.js Server-side Validation Demo</footer>
  <script src="/js/app.js"></script></body></html>`;
}

app.get("/", (req, res) => {
  const success = req.query.success === "1";
  const errors = req.query.error ? `<div class="alert error">${escapeHtml(req.query.error)}</div>` : "";
  res.send(page("Create account", `<section class="hero"><div class="eyebrow">SERVER-SIDE VALIDATION</div>
    <h1>Reliable forms.<br><span>Validated on the server.</span></h1>
    <p>Submit your details to see Express.js validation in action. The server checks every field before saving the record.</p>
    <div class="trust-row"><span>✓ Required fields</span><span>✓ Email format</span><span>✓ Password rules</span></div></section>
    <section class="form-card"><div class="card-heading"><div><h2>Create your account</h2><p>All fields are required unless marked optional.</p></div><span class="step">01 / 01</span></div>
    ${success ? '<div class="alert success">Registration successful. Your details passed server-side validation.</div>' : ""}
    ${errors}
    <form action="/register" method="POST" id="registrationForm" novalidate>
      <div class="field-grid">
        <label>Full name<input name="name" type="text" placeholder="e.g. Aditi Sharma" minlength="2" maxlength="60" required><small>2–60 characters</small></label>
        <label>Email address<input name="email" type="email" placeholder="you@example.com" maxlength="120" required><small>Use a valid email address</small></label>
        <label>Phone number<input name="phone" type="tel" placeholder="9876543210" required><small>10 digits, starting 6–9</small></label>
        <label>Department<select name="department" required><option value="">Choose department</option><option>Engineering</option><option>Design</option><option>Marketing</option><option>Operations</option><option>Human Resources</option></select><small>Select one department</small></label>
        <label>Password<input name="password" type="password" placeholder="At least 8 characters" minlength="8" required><small>8+ characters, uppercase, lowercase and number</small></label>
        <label>Confirm password<input name="confirmPassword" type="password" placeholder="Re-enter password" required><small>Must match the password above</small></label>
      </div>
      <label class="check"><input type="checkbox" name="terms" value="yes" required> I confirm that the information provided is accurate.</label>
      <button class="button primary full" type="submit">Validate &amp; register <span>→</span></button>
      <p class="form-note">Validation is performed on the Express.js server using express-validator.</p>
    </form></section>`, "registration"));
});

app.post("/register", [
  body("name").trim().isLength({ min: 2, max: 60 }).withMessage("Name must be between 2 and 60 characters.").matches(/^[\p{L} .'-]+$/u).withMessage("Name can contain letters, spaces, apostrophes, periods and hyphens only."),
  body("email").trim().isEmail().withMessage("Enter a valid email address.").normalizeEmail().isLength({ max: 120 }).withMessage("Email is too long."),
  body("phone").trim().matches(/^[6-9]\d{9}$/).withMessage("Phone number must be 10 digits and start with 6, 7, 8 or 9."),
  body("department").isIn(["Engineering", "Design", "Marketing", "Operations", "Human Resources"]).withMessage("Choose a valid department."),
  body("password").isLength({ min: 8, max: 72 }).withMessage("Password must contain at least 8 characters.").matches(/[a-z]/).withMessage("Password must include a lowercase letter.").matches(/[A-Z]/).withMessage("Password must include an uppercase letter.").matches(/\d/).withMessage("Password must include a number."),
  body("confirmPassword").custom((value, { req }) => value === req.body.password).withMessage("Passwords do not match."),
  body("terms").equals("yes").withMessage("You must confirm that the information is accurate.")
], (req, res) => {
  const result = validationResult(req);
  if (!result.isEmpty()) {
    const message = result.array().map(e => e.msg).join(" ");
    return res.redirect("/?error=" + encodeURIComponent(message));
  }
  const users = readUsers();
  const email = req.body.email.trim().toLowerCase();
  if (users.some(user => user.email === email)) {
    return res.redirect("/?error=" + encodeURIComponent("An account with this email already exists."));
  }
  users.unshift({
    id: `FG-${Date.now().toString().slice(-8)}`,
    name: req.body.name.trim(),
    email,
    phone: req.body.phone.trim(),
    department: req.body.department,
    createdAt: new Date().toISOString()
  });
  saveUsers(users);
  return res.redirect("/?success=1");
});

app.get("/admin/login", (req, res) => {
  res.send(page("Admin login", `<section class="login-wrap"><div class="login-card">
    <div class="admin-icon">⌘</div><div class="eyebrow">RESTRICTED AREA</div><h1>Admin sign in</h1>
    <p>Access registration records and dashboard analytics.</p>
    ${req.query.error ? `<div class="alert error">${escapeHtml(req.query.error)}</div>` : ""}
    <form method="POST" action="/admin/login">
      <label>Username<input name="username" autocomplete="username" placeholder="Enter admin username" required></label>
      <label>Password<input name="password" type="password" autocomplete="current-password" placeholder="Enter admin password" required></label>
      <button class="button primary full">Sign in <span>→</span></button>
    </form><div class="demo-credentials"><strong>Demo credentials</strong><br>Username: <code>admin</code> · Password: <code>Admin@123</code></div>
    <a class="back-link" href="/">← Back to registration</a></div></section>`));
});
app.post("/admin/login", (req, res) => {
  const username = process.env.ADMIN_USERNAME || "admin";
  const password = process.env.ADMIN_PASSWORD || "Admin@123";
  if (req.body.username === username && req.body.password === password) {
    req.session.isAdmin = true;
    return res.redirect("/admin");
  }
  return res.redirect("/admin/login?error=" + encodeURIComponent("Incorrect username or password."));
});
app.post("/admin/logout", (req, res) => {
  req.session.destroy(() => res.redirect("/admin/login"));
});
app.get("/admin", requireAdmin, (req, res) => {
  const users = readUsers();
  const departments = [...new Set(users.map(u => u.department))].length;
  const rows = users.map(u => `<tr><td><span class="record-id">${escapeHtml(u.id)}</span></td><td><strong>${escapeHtml(u.name)}</strong><small class="table-sub">${escapeHtml(u.email)}</small></td><td>${escapeHtml(u.phone)}</td><td><span class="dept-pill">${escapeHtml(u.department)}</span></td><td>${new Date(u.createdAt).toLocaleDateString("en-IN", { day: "2-digit", month: "short", year: "numeric" })}</td></tr>`).join("");
  res.send(page("Admin dashboard", `<div class="dashboard-head"><div><div class="eyebrow">OVERVIEW / ADMIN</div><h1>Dashboard</h1><p>Monitor registrations and review validated submissions.</p></div>
    <form method="POST" action="/admin/logout"><button class="button outline">Sign out ↗</button></form></div>
    <section class="stats"><article class="stat-card"><div class="stat-top"><span>Total registrations</span><span class="stat-icon blue">↗</span></div><strong>${users.length}</strong><small>Validated records stored</small></article>
    <article class="stat-card"><div class="stat-top"><span>Departments represented</span><span class="stat-icon orange">▦</span></div><strong>${departments}</strong><small>Across submitted records</small></article>
    <article class="stat-card"><div class="stat-top"><span>Validation status</span><span class="stat-icon green">✓</span></div><strong>Active</strong><small>Server-side checks enabled</small></article></section>
    <section class="table-card"><div class="table-head"><div><h2>Registration records</h2><p>Each record passed server-side validation.</p></div><div class="table-actions"><input id="tableSearch" type="search" placeholder="Search records…"><button class="button outline" onclick="window.print()" type="button">Export / Print</button></div></div>
    <div class="table-scroll"><table id="usersTable"><thead><tr><th>Record ID</th><th>Name / Email</th><th>Phone</th><th>Department</th><th>Date added</th></tr></thead><tbody>${rows || '<tr><td colspan="5" class="empty-state">No registrations yet. Submit the public form to add a record.</td></tr>'}</tbody></table></div>
    <div class="table-foot"><span>Showing <strong id="visibleCount">${users.length}</strong> record(s)</span><span>Data source: local JSON file</span></div></section>
    <div class="dashboard-note"><span class="note-icon">i</span><div><strong>Demo security note</strong><p>Change the demo admin credentials and session secret before public deployment. For production, use a database, hashed passwords, CSRF protection and a persistent session store.</p></div></div>`));
});

app.use((req, res) => res.status(404).send(page("Not found", `<section class="not-found"><div class="eyebrow">ERROR 404</div><h1>Page not found</h1><p>The page you're looking for doesn't exist.</p><a class="button primary" href="/">Return home →</a></section>`)));

app.listen(PORT, () => console.log(`FormGuard running at http://localhost:${PORT}`));

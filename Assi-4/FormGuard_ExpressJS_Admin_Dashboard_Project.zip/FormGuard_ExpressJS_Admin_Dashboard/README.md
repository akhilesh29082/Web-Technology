# FormGuard — Express.js Server-side Validation

A polished coursework project demonstrating server-side form validation with Express.js and `express-validator`, with an admin login and registration dashboard.

## Features
- Responsive registration form with a professional UI.
- Server-side validation for name, email, phone, department, password, confirmation and terms.
- Duplicate-email prevention.
- Registration data persisted to `data/users.json` (demo storage).
- Admin login, summary cards, searchable records table, and print/export via browser.
- Express session and basic 404 page.

## Requirements
- Node.js 18 or newer
- npm

## Run locally
1. Extract the ZIP file.
2. Open the extracted folder in VS Code.
3. Open Terminal → New Terminal.
4. Install dependencies:
   ```bash
   npm install
   ```
5. Start the application:
   ```bash
   npm start
   ```
6. Open `http://localhost:3000`.

## Admin dashboard
- URL: `http://localhost:3000/admin/login`
- Demo username: `admin`
- Demo password: `Admin@123`

For local coursework demonstration only. Before deployment, set `ADMIN_USERNAME`, `ADMIN_PASSWORD`, and a strong `SESSION_SECRET` environment variable. Do not use the demo credentials on a public site.

## Validation rules
- Name: 2–60 characters; letters, spaces, apostrophes, periods and hyphens.
- Email: valid email format, normalized, maximum 120 characters.
- Phone: 10 digits, first digit 6–9 (India-oriented rule).
- Department: one of the listed options.
- Password: minimum 8 characters and includes uppercase, lowercase and a number.
- Confirm password: must match.
- Terms checkbox: must be accepted.
- Duplicate email: rejected.

## Project structure
```
express_validation_admin_project/
├── data/
│   └── users.json
├── public/
│   ├── css/styles.css
│   └── js/app.js
├── package.json
├── server.js
└── README.md
```

## Important production note
This is a teaching/demo implementation. JSON-file storage is not intended for concurrent production use. A real deployment should use a database, hash stored passwords (this project does not store passwords), use environment-managed secrets, add CSRF protection, rate limiting, stronger session storage and HTTPS.
